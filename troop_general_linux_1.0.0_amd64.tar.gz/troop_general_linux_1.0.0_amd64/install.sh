#!/bin/bash
OS_DESC=''
OTHERS_OS='OTHERS'
CURRENT_OS=''

support_os_list=("CENTOS" "SUSE" "DEBIAN" "EULER" "UBUNTU" "FEDORA" "ORACLE LINUX")
chkconfig_os_list=("CENTOS" "SUSE" "EULER" "FEDORA" "ORACLE LINUX")
update_rc_os_list=("DEBIAN" "UBUNTU")

telecoped_service="[Unit]
Description=troop-generald service
After=network.target

[Service]
Type=simple
ExecStart=/etc/init.d/troop-generald start
RemainAfterExit=yes
ExecStop=/etc/init.d/troop-generald stop
KillMode=none

[Install]
WantedBy=multi-user.target
"

if [ "`id -u`" = "0" ] || [ "`id -g`" = "0" ] ; then
    echo "Current user is root."
else
    echo "Current user is not root, please use root user install or command [sudo sh install.sh]."
    exit 0
fi

getStatus()
{
    PARENT_PIDS=($(pgrep troop-general$ | awk '{print $1}'))
    for ppid in ${PARENT_PIDS[*]}
    do
        return 0
    done
    return 1
}

getCurrentPath()
{
    if [ "` dirname "$0" `" = "" ] || [ "` dirname "$0" `" = "." ] ; then
        CURRENT_DIR="`pwd`"
    else
        cd ` dirname "$0" `
        CURRENT_DIR="`pwd`"
        cd - > /dev/null 2>&1
    fi
}

#get linux os version description
getOS()
{
    if [ -f /usr/bin/lsb_release ]; then
        OS_DESC=$(/usr/bin/lsb_release -a |grep Description |awk -F : '{print $2}' |sed 's/^[ \t]*//g')
    elif [ -f /etc/system-release ]; then
        OS_DESC=$(cat /etc/system-release | sed -n '1p')
    else
        OS_DESC=$(cat /etc/issue | sed -n '1p')
    fi
}

getStatus
status=$?
if [ ${status} == 0 ]; then
    echo "troop-general is running, so can't be installed"
    exit 1
fi

getCurrentPath
getOS


chmod 755 ${CURRENT_DIR} -R
chown root ${CURRENT_DIR} -R
chgrp root ${CURRENT_DIR} -R

chmod 755 troop-generald -R

INSTALL_DIR=/usr/local/troop-general
if [[ "$1" && ! -d "$1" ]]; then
    echo "$1" is not a directory! Install troop-general failed.
    exit -1
fi
if [[ "$1" && -d "$1" ]]; then
    INSTALL_DIR="$1"/troop-general
fi

old=$(grep '^BIN_DIR=' ${CURRENT_DIR}"/troop-generald")
sed -i 's#^'"$old"'#BIN_DIR='''"$INSTALL_DIR"'''#g' ${CURRENT_DIR}"/troop-generald"

# get current linux os version
CURRENT_OS=${OTHERS_OS}
for support_os in "${support_os_list[@]}"
do 
    if [ `echo ${OS_DESC} | tr [a-z] [A-Z] | grep "${support_os}" | wc -l` -ge 1 ] ; then
        CURRENT_OS=${support_os}
    fi
done
   
echo "Current linux release version : ${CURRENT_OS}"
echo "Start to install troop-general..."

mkdir -p ${INSTALL_DIR}
mkdir -p ${INSTALL_DIR}/log
cp -R ${CURRENT_DIR}/bin ${INSTALL_DIR}
cp -R ${CURRENT_DIR}/conf ${INSTALL_DIR}
cp ${CURRENT_DIR}/troop-generald ${INSTALL_DIR}
cp ${CURRENT_DIR}/uninstall.sh ${INSTALL_DIR}

# add troop-generald service and set up autostart
if [[ "${chkconfig_os_list[@]}" =~ $CURRENT_OS ]]; then
    echo "In chkconfig "
    cp ${CURRENT_DIR}"/troop-generald" /etc/init.d
    chkconfig --add troop-generald
    chkconfig troop-generald on
elif [[ "${update_rc_os_list[@]}" =~ $CURRENT_OS ]]; then
    echo "In update-rc.d "
    cp ${CURRENT_DIR}"/troop-generald" /etc/init.d
    update-rc.d troop-generald defaults
else
    if command -v chkconfig >/dev/null 2>&1; then 
        cp ${CURRENT_DIR}"/troop-generald" /etc/init.d
        chkconfig --add troop-generald
        chkconfig troop-generald on
    elif command -v update-rc.d >/dev/null 2>&1; then 
        cp ${CURRENT_DIR}"/troop-generald" /etc/init.d
        update-rc.d troop-generald defaults
    elif command -v rc-update >/dev/null 2>&1; then 
        cp ${CURRENT_DIR}"/troop-generald" /etc/init.d
        rc-update add troop-generald default
        if [ -d /etc/local.d ]; then
            touch /etc/local.d/troop-generald.start
            chmod 755 /etc/local.d/troop-generald.start
            echo "/etc/init.d/troop-generald start" > /etc/local.d/troop-generald.start
        fi
    elif command -v systemctl >/dev/null 2>&1; then 
        cp ${CURRENT_DIR}"/troop-generald" /etc/init.d
        touch /etc/systemd/system/troop-generald.service
        chmod 644 /etc/systemd/system/troop-generald.service
        echo "$telecoped_service" > /etc/systemd/system/troop-generald.service
        systemctl enable troop-generald
    else
        echo "Unsupported register command, autostarts unsupported linux"
        sh troop-generald start
        exit 0
    fi
fi

echo "Success to install troop-general to dir: ${INSTALL_DIR}."

exit 0

