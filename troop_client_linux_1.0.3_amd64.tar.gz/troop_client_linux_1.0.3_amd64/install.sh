#!/bin/bash
OS_DESC=''
OTHERS_OS='OTHERS'
CURRENT_OS=''

support_os_list=("CENTOS" "SUSE" "DEBIAN" "EULER" "UBUNTU" "FEDORA" "ORACLE LINUX")
chkconfig_os_list=("CENTOS" "SUSE" "EULER" "FEDORA" "ORACLE LINUX")
update_rc_os_list=("DEBIAN" "UBUNTU")

if [ "`id -u`" = "0" ] || [ "`id -g`" = "0" ] ; then
    echo "Current user is root."
else
    echo "Current user is not root, please use root user install or command [sudo sh install.sh]."
    exit 0
fi

getCurrentPath()
{
    if [ "` dirname "$0" `" = "" ] || [ "` dirname "$0" `" = "." ] ; then
        CURRENT_DIR="`pwd`"
    else
        cd ` dirname "$0" `
        CURRENT_DIR="`pwd`"
        cd - > /dev/null 2>&1
    fi
}

#get linux os version description
getOS()
{
    if [ -f /usr/bin/lsb_release ]; then
        OS_DESC=$(/usr/bin/lsb_release -a |grep Description |awk -F : '{print $2}' |sed 's/^[ \t]*//g')
    elif [ -f /etc/system-release ]; then
        OS_DESC=$(cat /etc/system-release | sed -n '1p')
    else
        OS_DESC=$(cat /etc/issue | sed -n '1p')
    fi
}


getCurrentPath
getOS


chmod 755 ${CURRENT_DIR} -R
chown root ${CURRENT_DIR} -R
chgrp root ${CURRENT_DIR} -R

INSTALL_DIR=/usr/local/troop-client
if [[ "$1" && ! -d "$1" ]]; then
    echo "$1" is not a directory! Install troop-client failed.
    exit -1
fi
if [[ "$1" && -d "$1" ]]; then
    INSTALL_DIR="$1"/troop-client
fi

# get current linux os version
CURRENT_OS=${OTHERS_OS}
for support_os in "${support_os_list[@]}"
do 
    if [ `echo ${OS_DESC} | tr [a-z] [A-Z] | grep "${support_os}" | wc -l` -ge 1 ] ; then
        CURRENT_OS=${support_os}
    fi
done
   
echo "Current linux release version : ${CURRENT_OS}"
echo "Start to install troop-client..."

mkdir -p ${INSTALL_DIR}
mkdir -p ${INSTALL_DIR}/log
cp -R ${CURRENT_DIR}/bin ${INSTALL_DIR}
ln -s ${CURRENT_DIR}/bin/troop /usr/local/bin
cp -R ${CURRENT_DIR}/conf ${INSTALL_DIR}
cp ${CURRENT_DIR}/uninstall.sh ${INSTALL_DIR}


echo "Success to install troop-client to dir: ${INSTALL_DIR}."  0/

exit 0

